#pragma once

#include "../../../includes/in_memory_block_device.hpp"
#include "../../../includes/file_system.hpp"
#include "filesystem.grpc.pb.h"

class FileSystemImpl : public NfsService::Service
{
private:
    InMemoryBlockDevice device;
    FileSystem fs;

public:
    FileSystemImpl();
    ~FileSystemImpl();
    ::grpc::Status CreateFile(::grpc::ServerContext *context, const ::CreateFileRequest *request, ::CreateFileResponse *response) override;
    ::grpc::Status ReadFile(::grpc::ServerContext *context, const ::ReadFileRequest *request, ::ReadFileResponse *response) override;
    ::grpc::Status WriteFile(::grpc::ServerContext *context, const ::WriteFileRequest *request, ::WriteFileResponse *response) override;
    ::grpc::Status Mkdir(::grpc::ServerContext *context, const ::MkdirRequest *request, ::MkdirResponse *response) override;
    ::grpc::Status Delete(::grpc::ServerContext *context, const ::DeleteRequest *request, ::DeleteResponse *response) override;
    ::grpc::Status Readdir(::grpc::ServerContext *context, const ::ReaddirRequest *request, ::ReaddirResponse *response) override;
};