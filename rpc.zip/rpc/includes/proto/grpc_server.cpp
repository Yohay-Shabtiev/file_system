#include "grpc_server.hpp"

FileSystemImpl::FileSystemImpl()
    : device(TOTAL_BLOCKS_NUMBER * BLOCK_SIZE), fs(device)
{
    fs.format();
}

FileSystemImpl ::~FileSystemImpl()
{
}

::grpc::Status FileSystemImpl::CreateFile(::grpc::ServerContext *context, const ::CreateFileRequest *request, ::CreateFileResponse *response)
{
    auto file_res = fs.create_file(request->parent_inode_id(), request->file_name());
    if (!file_res.has_value())
    {
        response->set_status(to_grpc_status(file_res.error()));
        response->set_new_inode_id(-1);
        return grpc::Status::OK;
    }

    response->set_new_inode_id(file_res.value());
    response->set_status(grpc::Status::OK);
    return response->gets;
}
::grpc::Status FileSystemImpl::ReadFile(::grpc::ServerContext *context, const ::ReadFileRequest *request, ::ReadFileResponse *response)
{
}
::grpc::Status FileSystemImpl::WriteFile(::grpc::ServerContext *context, const ::WriteFileRequest *request, ::WriteFileResponse *response)
{
}
::grpc::Status FileSystemImpl::Mkdir(::grpc::ServerContext *context, const ::MkdirRequest *request, ::MkdirResponse *response) {}
::grpc::Status FileSystemImpl::Delete(::grpc::ServerContext *context, const ::DeleteRequest *request, ::DeleteResponse *response) {}
::grpc::Status FileSystemImpl::Readdir(::grpc::ServerContext *context, const ::ReaddirRequest *request, ::ReaddirResponse *response) {}

grpc::Status to_grpc_status(FileSystemStatus status)
{
    switch (status)
    {
    case FileSystemStatus::OK:
        return grpc::Status::OK;
    case FileSystemStatus::NotFound:
        return grpc::Status(grpc::StatusCode::NOT_FOUND, "entry not found");
    case FileSystemStatus::FullDisk:
        return grpc::Status(grpc::StatusCode::RESOURCE_EXHAUSTED, "disk full");
    case FileSystemStatus::NotEmpty:
        return grpc::Status(grpc::StatusCode::FAILED_PRECONDITION, "directory not empty");
    case FileSystemStatus::InodeNotFound:
        return grpc::Status(grpc::StatusCode::NOT_FOUND, "inode not found");
    default:
        return grpc::Status(grpc::StatusCode::INTERNAL, "unknown error");
    }
}
